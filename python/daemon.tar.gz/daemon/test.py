import subprocess

res = subprocess.Popen([''], stdout=subprocess.PIPE, shell=True)
res1 = subprocess.Popen([''], stdin=subprocess.PIPE, stdout=subprocess.PIPE, shell=True)
res1.stdin.write(res.communicate()[0])
print res1.communicate()
